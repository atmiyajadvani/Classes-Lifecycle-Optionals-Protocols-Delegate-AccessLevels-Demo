

protocol AdvancedLifeSupport {
    func performCPR()
}

class EmergencyCallHandler {
    var delegate : AdvancedLifeSupport?
    
    func assessSituation() {
        print("Tell me what happened?")
    }
    
    func medicalEmergency() {
        delegate?.performCPR()
    }

}

struct Paramedic: AdvancedLifeSupport {
    
    init(handler: EmergencyCallHandler) {
        handler.delegate = self
    }
    
    func performCPR() {
        print("the paramedic does chest compressions on the patient, 30 per second")
    }
    
}

class Doctor: AdvancedLifeSupport {
    
    init(handler: EmergencyCallHandler) {
        handler.delegate = self
    }
    
    
    func performCPR() {
        print("the paramedic does chest compressions on the patient, 30 per second")
    }
    
    func useSthescope() {
        print("Listening to heart beats!")
    }
}


class Surgeon: Doctor {
    override func performCPR() {
        super.performCPR()
        print("Sings staying alive song")
        
    }
    
    func useElectricDrill() {
        print("whirrr....")
    }
}

let emilio = EmergencyCallHandler()
let angela = Surgeon(handler: emilio)

emilio.assessSituation()
emilio.medicalEmergency()



