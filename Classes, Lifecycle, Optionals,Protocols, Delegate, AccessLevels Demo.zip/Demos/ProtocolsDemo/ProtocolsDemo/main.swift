protocol CanFly {
    func fly() 
}

class Bird {
    
    var isFemale = true
    
    func layEgg() {
        if isFemale {
            print("Lay Eggs")
        }
    }
    
    func fly() {
        print("Lifts off and flies up in the sky!")
    }
}

class Eagle: Bird {
    
    func soar() {
        print("The eagle glides in the air with the air currents")
    }
}

class Penguin: Bird {
    func swim() {
        print("Penguins can Swim and paddle through water")
    }
}

struct FlyingMueseum {
    func flyingDemo(flyingObject: Bird) {
        flyingObject.fly()
    }
}

class Airplane: Bird {
    
}




let myEagle = Eagle()
myEagle.fly()
myEagle.layEgg()
myEagle.soar()

let myPenguin = Penguin()
myPenguin.layEgg()
myPenguin.swim()
myPenguin.fly() // Penguins don't fly

let myPlane = Airplane()

let museum = FlyingMueseum()
museum.flyingDemo(flyingObject: myPenguin)
