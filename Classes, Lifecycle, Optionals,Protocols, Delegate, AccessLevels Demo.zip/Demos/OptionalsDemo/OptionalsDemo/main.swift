
let myOptional: String?

myOptional = nil

if myOptional != nil {
    let text: String = myOptional!
} else {
    print("MyOptional was found to be nil")
}
