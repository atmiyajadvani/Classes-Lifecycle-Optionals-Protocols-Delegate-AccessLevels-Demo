// When making a Class, the name of the class has to match the name of the file

class Enemy {
    var health = 100
    var attackStrength = 10
    
    func move(){
        print("Walk foreward")
    }
    
    func attack() {
        print("Land a hit,does \(attackStrength) damage.")
    }
    
}
