

let skeleton = Enemy()

let dragon = Dragon()
dragon.wingSpan = 5
dragon.attackStrength = 15
dragon.talk(speech: "my teeth are swords!!")
dragon.move()
dragon.attack()
